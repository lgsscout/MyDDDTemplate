﻿using System;

namespace $safeprojectname$.ViewModels
{
    public class ExampleEditViewModel
    {
        public Guid ID { get; set; }
        public string Description { get; set; }
    }
}