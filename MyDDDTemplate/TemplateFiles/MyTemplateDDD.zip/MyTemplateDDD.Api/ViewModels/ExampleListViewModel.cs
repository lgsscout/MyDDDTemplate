﻿using System;

namespace $safeprojectname$.ViewModels
{
    public class ExampleListViewModel
    {
        public Guid ID { get; set; }
        public string Description { get; set; }
    }
}