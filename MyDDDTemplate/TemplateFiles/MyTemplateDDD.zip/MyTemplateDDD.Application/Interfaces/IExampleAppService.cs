﻿using $safeprojectname$.Interfaces.Common;
using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.Domain.Validation;
using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Interfaces
{
    public interface IExampleAppService: IBaseAppService<Example>
    {
    }
}
