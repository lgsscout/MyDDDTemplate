﻿using $safeprojectname$.Entities;
using $safeprojectname$.Interfaces.Repository.Common;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace $safeprojectname$.Interfaces.Repository
{
    public interface IExampleRepository : IRepository<Example>
    {
    }
}
