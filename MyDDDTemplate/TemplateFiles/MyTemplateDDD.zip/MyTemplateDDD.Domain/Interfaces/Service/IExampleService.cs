﻿using $safeprojectname$.Entities;
using $safeprojectname$.Interfaces.Service.Common;
using System.Collections.Generic;

namespace $safeprojectname$.Interfaces.Service
{
    public interface IExampleService: IService<Example>
    {
    }
}